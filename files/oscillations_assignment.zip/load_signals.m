
%% Load data

sMat = load('signals_for_lecture.mat');
% sMat.Value             : signals (number of signals x number of samples)
% sMat.Time              : time vector (1 x number of samples)
% sMat.Events            : structure array that holds the event information
% sMat.Events(1)         : Start of visual stimulus (Contracting circular grating)
% sMat.Events(2)         : Change of contraction speed
% sMat.Events(3)         : Subject response (button press)
% sMat.Events(1).times   : Vector of event times
% sMat.Events(1).samples : Vector of event samples

% Plot
figure(1); clf; hold on;
plot(sMat.Time, sMat.Value')
plot(sMat.Events(1).times, 0, 'ko')
plot(sMat.Events(2).times, 0, 'kx')
plot(sMat.Events(3).times, 0, 'kv')
legend('signal 1', 'signal 2', 'signal 3', 'start', 'change', 'response')
